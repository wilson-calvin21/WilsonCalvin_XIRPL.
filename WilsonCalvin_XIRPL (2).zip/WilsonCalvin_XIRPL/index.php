<?php
require_once 'koneksi.php';

$stmt = $koneksi->prepare(
    "SELECT * FROM presensi_eskul ORDER BY id_presensi DESC"
);

if (!$stmt) {
    die("Query gagal: " . $koneksi->error);
}

$stmt->execute();
$data = $stmt->get_result();

function aman($nilai) {
    return htmlspecialchars((string)$nilai, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Presensi Eskul Wilson</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <span class="navbar-brand">Presensi Eskul Wilson</span>
    </div>
</nav>

<div class="container py-5">
    <div class="card shadow-sm">
        <div class="card-body">

            <h3>Data Presensi Ekstrakurikuler</h3>
            <p class="text-muted">Sistem Presensi Kegiatan Sekolah</p>

            <a href="tambah.php" class="btn btn-primary mb-3">
                + Tambah Presensi
            </a>

            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>No.</th>
                            <th>Nama Peserta</th>
                            <th>Kelas</th>
                            <th>Ekstrakurikuler</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php if ($data->num_rows > 0): ?>
                        <?php $no = 1; ?>

                        <?php while ($row = $data->fetch_assoc()): ?>
                            <?php
                            $warna = [
                                'hadir' => 'success',
                                'izin'  => 'warning',
                                'sakit' => 'info',
                                'alpa'  => 'danger'
                            ];

                            $status = strtolower($row['status']);
                            ?>

                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= aman($row['nama_presensi']) ?></td>
                                <td><?= aman($row['kelas']) ?></td>
                                <td><?= aman($row['ekstrakurikuler']) ?></td>
                                <td><?= aman($row['tanggal']) ?></td>

                                <td>
                                    <span class="badge bg-<?= $warna[$status] ?? 'secondary' ?>">
                                        <?= strtoupper(aman($status)) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= aman($row['keterangan'] ?? '-') ?>
                                </td>

                                <td>
                                    <div class="d-flex gap-1">
                                        <a href="edit.php?id=<?= (int)$row['id_presensi'] ?>"
                                           class="btn btn-warning btn-sm">
                                            Edit
                                        </a>

                                        <form action="hapus.php" method="post"
                                              onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                            <input type="hidden" name="id"
                                                   value="<?= (int)$row['id_presensi'] ?>">

                                            <button type="submit"
                                                    class="btn btn-danger btn-sm">
                                                Hapus
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center">
                                Belum ada data presensi.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

</body>
</html>

<?php
$stmt->close();
$koneksi->close();
?>