<?php
require_once 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit;
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    header("Location: index.php");
    exit;
}

$stmt = $koneksi->prepare(
    "DELETE FROM presensi_eskul WHERE id_presensi = ?"
);

if (!$stmt) {
    die("Prepare gagal: " . $koneksi->error);
}

$stmt->bind_param("i", $id);

if (!$stmt->execute()) {
    die("Gagal menghapus data: " . $stmt->error);
}

$stmt->close();
$koneksi->close();

header("Location: index.php");
exit;
?>