<?php
require_once 'koneksi.php';

$error = '';

$nama = '';
$kelas = '';
$eskul = '';
$tanggal = '';
$status = '';
$keterangan = '';

function aman($nilai) {
    return htmlspecialchars((string)$nilai, ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama_presensi'] ?? '');
    $kelas = trim($_POST['kelas'] ?? '');
    $eskul = trim($_POST['ekstrakurikuler'] ?? '');
    $tanggal = $_POST['tanggal'] ?? '';
    $status = $_POST['status'] ?? '';
    $keterangan = trim($_POST['keterangan'] ?? '');

    $statusValid = ['hadir', 'izin', 'sakit', 'alpa'];

    $objTanggal = $tanggal !== ''
        ? DateTime::createFromFormat('!Y-m-d', $tanggal)
        : false;

    $tanggalValid = $objTanggal
        && $objTanggal->format('Y-m-d') === $tanggal;

    if (
        $nama === '' ||
        $kelas === '' ||
        $eskul === '' ||
        !$tanggalValid ||
        !in_array($status, $statusValid, true)
    ) {
        $error = 'Semua field wajib diisi dengan benar.';
    } elseif (
        strlen($nama) > 200 ||
        strlen($kelas) > 80 ||
        strlen($eskul) > 200 ||
        strlen($keterangan) > 400
    ) {
        $error = 'Panjang input melebihi batas kolom database.';
    } else {
        $stmt = $koneksi->prepare(
            "INSERT INTO presensi_eskul
            (nama_presensi, kelas, ekstrakurikuler, tanggal, status, keterangan)
            VALUES (?, ?, ?, ?, ?, ?)"
        );

        if (!$stmt) {
            die("Prepare gagal: " . $koneksi->error);
        }

        $stmt->bind_param(
            "ssssss",
            $nama,
            $kelas,
            $eskul,
            $tanggal,
            $status,
            $keterangan
        );

        if ($stmt->execute()) {
            $stmt->close();
            header("Location: index.php");
            exit;
        } else {
            $error = "Gagal menyimpan data: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Presensi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="card shadow-sm mx-auto" style="max-width: 650px">
        <div class="card-body">

            <h3 class="mb-4">Tambah Data Presensi</h3>

            <?php if ($error !== ''): ?>
                <div class="alert alert-danger"><?= aman($error) ?></div>
            <?php endif; ?>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Nama Peserta</label>
                    <input type="text" name="nama_presensi"
                           class="form-control" maxlength="50"
                           value="<?= aman($nama) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kelas</label>
                    <input type="text" name="kelas"
                           class="form-control" maxlength="20"
                           value="<?= aman($kelas) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Ekstrakurikuler</label>
                    <input type="text" name="ekstrakurikuler"
                           class="form-control" maxlength="50"
                           value="<?= aman($eskul) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tanggal Kegiatan</label>
                    <input type="date" name="tanggal"
                           class="form-control"
                           value="<?= aman($tanggal) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Status Kehadiran</label>
                    <select name="status" class="form-select" required>
                        <option value="">-- Pilih Status --</option>

                        <?php foreach (['hadir', 'izin', 'sakit', 'alpa'] as $s): ?>
                            <option value="<?= $s ?>"
                                <?= $status === $s ? 'selected' : '' ?>>
                                <?= strtoupper($s) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Keterangan (Opsional)</label>
                    <textarea name="keterangan" class="form-control"
                            maxlength="100" rows="3"><?= aman($keterangan) ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">
                    Simpan Data
                </button>

                <a href="index.php" class="btn btn-secondary">
                    Kembali
                </a>
            </form>

        </div>
    </div>
</div>

</body>
</html>