<?php
require_once 'koneksi.php';

function aman($nilai) {
    return htmlspecialchars((string)$nilai, ENT_QUOTES, 'UTF-8');
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    header("Location: index.php");
    exit;
}

$stmt = $koneksi->prepare(
    "SELECT * FROM presensi_eskul WHERE id_presensi = ?"
);

if (!$stmt) {
    die("Prepare gagal: " . $koneksi->error);
}

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    die("Data presensi tidak ditemukan.");
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama_presensi'] ?? '');
    $kelas = trim($_POST['kelas'] ?? '');
    $eskul = trim($_POST['ekstrakurikuler'] ?? '');
    $tanggal = $_POST['tanggal'] ?? '';
    $status = $_POST['status'] ?? '';
    $keterangan = trim($_POST['keterangan'] ?? '');

    $statusValid = ['hadir', 'izin', 'sakit', 'alpa'];

    $objTanggal = $tanggal !== ''
        ? DateTime::createFromFormat('!Y-m-d', $tanggal)
        : false;

    $tanggalValid = $objTanggal
        && $objTanggal->format('Y-m-d') === $tanggal;

    if (
        $nama === '' ||
        $kelas === '' ||
        $eskul === '' ||
        !$tanggalValid ||
        !in_array($status, $statusValid, true)
    ) {
        $error = 'Periksa kembali semua field.';
    } elseif (
        strlen($nama) > 200 ||
        strlen($kelas) > 80 ||
        strlen($eskul) > 200 ||
        strlen($keterangan) > 400
    ) {
        $error = 'Panjang input melebihi batas kolom database.';
    } else {
        $stmt = $koneksi->prepare(
            "UPDATE presensi_eskul
             SET nama_presensi = ?,
                 kelas = ?,
                 ekstrakurikuler = ?,
                 tanggal = ?,
                 status = ?,
                 keterangan = ?
             WHERE id_presensi = ?"
        );

        if (!$stmt) {
            die("Prepare gagal: " . $koneksi->error);
        }

        $stmt->bind_param(
            "ssssssi",
            $nama,
            $kelas,
            $eskul,
            $tanggal,
            $status,
            $keterangan,
            $id
        );

        if ($stmt->execute()) {
            $stmt->close();
            header("Location: index.php");
            exit;
        } else {
            $error = "Gagal mengubah data: " . $stmt->error;
        }

        $stmt->close();
    }

    $row['nama_presensi'] = $nama;
    $row['kelas'] = $kelas;
    $row['ekstrakurikuler'] = $eskul;
    $row['tanggal'] = $tanggal;
    $row['status'] = $status;
    $row['keterangan'] = $keterangan;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Presensi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="card shadow-sm mx-auto" style="max-width: 650px">
        <div class="card-body">

            <h3 class="mb-4">Edit Data Presensi</h3>

            <?php if ($error !== ''): ?>
                <div class="alert alert-danger"><?= aman($error) ?></div>
            <?php endif; ?>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">ID Presensi</label>
                    <input type="text" class="form-control"
                        value="<?= (int)$row['id_presensi'] ?>" disabled>
                </div>

                <div class="mb-3">
                    <label class="form-label">Nama Peserta</label>
                    <input type="text" name="nama_presensi"
                        class="form-control" maxlength="50"
                        value="<?= aman($row['nama_presensi']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kelas</label>
                    <input type="text" name="kelas"
                        class="form-control" maxlength="20"
                        value="<?= aman($row['kelas']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Ekstrakurikuler</label>
                    <input type="text" name="ekstrakurikuler"
                        class="form-control" maxlength="50"
                        value="<?= aman($row['ekstrakurikuler']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tanggal Kegiatan</label>
                    <input type="date" name="tanggal"
                        class="form-control"
                        value="<?= aman($row['tanggal']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Status Kehadiran</label>
                    <select name="status" class="form-select" required>
                        <?php foreach (['hadir', 'izin', 'sakit', 'alpa'] as $s): ?>
                            <option value="<?= $s ?>"
                                <?= strtolower($row['status']) === $s ? 'selected' : '' ?>>
                                <?= strtoupper($s) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Keterangan (Opsional)</label>
                    <textarea name="keterangan" class="form-control"
                            maxlength="100" rows="3"><?= aman($row['keterangan'] ?? '') ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">
                    Simpan Perubahan
                </button>

                <a href="index.php" class="btn btn-secondary">
                    Kembali
                </a>
            </form>

        </div>
    </div>
</div>

</body>
</html>