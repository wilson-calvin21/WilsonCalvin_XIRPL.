-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2026 at 06:05 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `presensi_eskul_wilson`
--

-- --------------------------------------------------------

--
-- Table structure for table `presensi_eskul`
--

CREATE TABLE `presensi_eskul` (
  `id_presensi` int(11) NOT NULL,
  `nama_presensi` varchar(50) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `ekstrakurikuler` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `status` enum('hadir','izin','sakit','alpa') NOT NULL,
  `keterangan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `presensi_eskul`
--

INSERT INTO `presensi_eskul` (`id_presensi`, `nama_presensi`, `kelas`, `ekstrakurikuler`, `tanggal`, `status`, `keterangan`) VALUES
(2, 'wilson calvin', '11.RPL', 'badminton', '2026-10-30', 'hadir', 'djhwgr7wegfrjk'),
(3, 'jevin', '11.RPL', 'mos club', '2026-10-19', 'izin', 'mengikuti kegiatan ujian'),
(5, 'felix', '11.RPL', 'mos club', '2026-10-19', 'izin', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `presensi_eskul`
--
ALTER TABLE `presensi_eskul`
  ADD PRIMARY KEY (`id_presensi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `presensi_eskul`
--
ALTER TABLE `presensi_eskul`
  MODIFY `id_presensi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
